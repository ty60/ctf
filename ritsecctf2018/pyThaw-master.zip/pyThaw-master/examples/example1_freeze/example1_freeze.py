print("This is an example script!")

x = 12

if x == 12:
    x += 1
else:
    x += 2

print("x",x)

