import sys

def write(s):
    sys.stdout.write(s)
    sys.stdout.flush()
