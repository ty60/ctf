Download the attachment of SCSBX:Reversing for the source code and documentation of this VM.

The server is running
$ ./scsbx
