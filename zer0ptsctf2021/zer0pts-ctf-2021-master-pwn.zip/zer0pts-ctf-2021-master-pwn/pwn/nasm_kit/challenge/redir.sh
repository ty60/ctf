#! /bin/sh
cd /home/pwn && python3 server.py
