#! /bin/sh
cd /home/pwn && ./chall
