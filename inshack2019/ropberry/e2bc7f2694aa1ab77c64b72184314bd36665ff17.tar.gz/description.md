You hack this guy on challenge called `gimme-your-shell`, but he is still always asking me the same question when I try to find his secret. Maybe you can do something.

He is waiting for you at: `ssh -i <your_keyfile> -p 2226 user@ropberry.ctf.insecurity-insa.fr`
To find your keyfile, look into your profile on this website.

[binary](https://static.ctf.insecurity-insa.fr/e2bc7f2694aa1ab77c64b72184314bd36665ff17.tar.gz
)